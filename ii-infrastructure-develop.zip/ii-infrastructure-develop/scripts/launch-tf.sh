#!/usr/bin/bash

# pass in the environment name as the first parameter on the command line
# to automatically run the terraform apply command pass in 'apply' as the second parameter on the command line
#
# This script is designed to launch terraform running as a service principal
# There are several ways to do this.  We use a client id and client secret
# We do that by setting environment variables   ARM_TENANT_ID, ARM_SUBSCRIPTION_ID, ARM_CLIENT_ID and ARM_CLIENT_SECRET
# you may also run terraform in the context of a user principal using the az login command.  This requires the Az CLI. 
# For more information see https://www.terraform.io/docs/language/settings/backends/azurerm.html

SCRIPT_PATH=${0%/*}
cd $SCRIPT_PATH

# Load the environment variables
source secrets.txt

cd ..

# === Verify environment variables required for authentication ===
# These are needed if you need to run terraform as a service principal.


if [ -z "$ARM_CLIENT_ID" ] || [ "$ARM_CLIENT_ID" = "XXX" ] 
then
  echo "The ARM_CLIENT_ID environment variable is not set.  Please update secrets.txt"
  exit
fi

if [ -z "$ARM_CLIENT_SECRET" ] || [ "$ARM_CLIENT_SECRET" = "XXX" ] 
then
  echo "The ARM_CLIENT_SECRET environment variable is not set.  Please update secrets.txt"
  exit
fi

if [ -z "$ARM_TENANT_ID" ]
then
  echo "The ARM_TENANT_ID environment variable is not set.  Please update secrets.txt"
  exit
fi

if [ -z "$ARM_SUBSCRIPTION_ID" ]
then
  echo "The ARM_SUBSCRIPTION_ID environment variable is not set.  Please update secrets.txt"
  exit
fi

if [ -z "$1" ]
then
  echo "The environment name is required but missing.  Please enter the environment name on the command line"
  exit
else
  echo -e "\e[0;36mInitializing Terraform for the ==>  $1  <== environment\e[0m"
fi

# === Run terraform init ===

terraform init -reconfigure -backend-config="backend/$1.tfvars"

# === Run terraform plan and save the file ===

planfilename=`date '+%Y%m%d%H%M%S'.tfplan`

# Remove all old plan files
if ls *.tfplan > /dev/null 2>&1 
then
  rm *.tfplan
fi

terraform plan -var-file="vars/$1.tfvars.json" -out $planfilename

# === (optionally) Run terraform apply (NOTE: this will not prompt for approval)===

if [ "$2" = "apply" ]
then
  terraform apply "$planfilename"
fi

