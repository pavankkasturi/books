# This is only needed if you are running powershell scripts, which should not be the normal use case.
$ENV:TF_VAR_POSTGRES_USERNAME="XXX"
$ENV:TF_VAR_POSTGRES_PASSWORD="XXX"

$ENV:ARM_TENANT_ID="b68c6481-b22b-46b3-8c4c-0024bb9b9b1f"
$ENV:ARM_SUBSCRIPTION_ID="2ee64422-85a1-42e2-9b1e-2d649a48963c"
$ENV:ARM_CLIENT_ID="XXX"
$ENV:ARM_CLIENT_SECRET="XXX"