<#
   .Synopsis
   A script to create azure storage accounts and containers to be used by terraform for the backend state file storage.

   This script requires the Az CLI

   This script assumes a location of East US, the script will need to be updated if other locations are required.

#>


param (
    [string]$Environment_Type = "qat",
    [string]$Resource_Group = "rgiieusqa"
)
$location = "eastus"
$StgAcctName = "dgxiitfiaceus$Environment_Type"
$StgContainerName = "tfstatefiles"

az login --service-principal -u $ENV:ARM_CLIENT_ID -p $ENV:ARM_CLIENT_SECRET --tenant $ENV:ARM_TENANT_ID

$Status = az storage account check-name --name $StgAcctName | ConvertFrom-Json

If($Status.nameAvailable) {
    Write-Host "Creating Storage Account"
    az storage account create -n $StgAcctName -g $Resource_Group -l $location --sku Standard_GRS

    $ConnStrObj = az storage account show-connection-string -n $StgAcctName -g $Resource_Group  | ConvertFrom-Json

    Write-Host "Creating Storage Container"
    az storage container create --name $StgContainerName --connection-string $ConnStrObj.connectionString
} Else {
    Write-Host $Status.message -ForegroundColor Magenta
}