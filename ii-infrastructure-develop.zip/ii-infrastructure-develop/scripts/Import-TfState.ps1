<#
  .SYNOPSIS 
   This is a helper script to populate the Terraform State file for environments where resources already exist.

   It is intended to be run manually. And will import one specific environment at a time.
#>

param (
    [string]$Environment_Type = "qat",
    [string]$Environment_Name = "qafun",
    [switch]$ImportSharedResources
)

Push-Location $PSScriptRoot

# ===  Set the environment variables needed for authentication ===
# Be sure to set the secret values in secrets.ps1.  These are needed to perform the terraform init
. .\secrets.ps1

If ($null -eq $ENV:ARM_CLIENT_ID -or "XXX" -eq $ENV:ARM_CLIENT_ID){
    Write-Host "You must create a secrets.ps1 with valid values.  See example.secrets.ps1" -ForegroundColor Magenta
} Else {
    Write-Host "Authenticating with Client ID $ENV:ARM_CLIENT_ID "
}

Write-Host "Importing Resources for environment $Environment_Name from subscription $ENV:ARM_SUBSCRIPTION_ID"


Set-Location ".."
$WorkingDir = (Get-Location).Path

$TfVarJsonFilePath = "$PSScriptRoot\..\vars\$Environment_Type.tfvars.json"
$TfVars = Get-Content -Path $TfVarJsonFilePath | ConvertFrom-Json 

$AnalyticsName = "dgx-ii-la-eus-$Environment_Type"
$BaseAzResourceID = "/subscriptions/$ENV:ARM_SUBSCRIPTION_ID/resourceGroups"

# ===  Init ===
terraform init -backend-config="backend/$Environment_Type.tfvars"


# ===  Import Shared Resources ===
if($ImportSharedResources) {

    $AnalyticsId = "$BaseAzResourceID/$($TfVars.shared_resource_group)/providers/microsoft.operationalinsights/workspaces/$AnalyticsName"
    terraform import -var-file="vars\$Environment_Type.tfvars.json" azurerm_log_analytics_workspace.logAnalytics $AnalyticsId

    $PostgresId = "$BaseAzResourceID/$($TfVars.shared_resource_group)/providers/Microsoft.DBforPostgreSQL/servers/$($TfVars.Postgres_ServerName)"
    terraform import -var-file="vars\$Environment_Type.tfvars.json" azurerm_postgresql_server.sharedsrvr $PostgresId 
}

# ===  Import Environment Specific Resources ===
# This is a hassle because the arguments passed to `terraform import` contain quotation marks 

$RedisData = $TfVars.Redis.$Environment_Name

$RedisId = "$BaseAzResourceID/$($RedisData.resource_group)/providers/Microsoft.Cache/Redis/$($RedisData.Server_Name)"
$argList = @("import", "-var-file=`"vars\$Environment_Type.tfvars.json`"", "azurerm_redis_cache.caches[\`"$Environment_Name\`"]", $RedisId)
Start-Process "terraform" -NoNewWindow -Wait -ArgumentList $argList -WorkingDirectory $WorkingDir

$KeyVaultData = $TfVars.Key_Vault.$Environment_Name

$KeyVaultId = "$BaseAzResourceID/$($KeyVaultData.resource_group)/providers/Microsoft.KeyVault/vaults/$($KeyVaultData.name)"
$argList = @("import", "-var-file=`"vars\$Environment_Type.tfvars.json`"", "azurerm_key_vault.vaults[\`"$Environment_Name\`"]", $KeyVaultId)
Start-Process "terraform" -NoNewWindow -Wait -ArgumentList $argList -WorkingDirectory $WorkingDir

$KvAccessId = "$BaseAzResourceID/$($KeyVaultData.resource_group)/providers/Microsoft.KeyVault/vaults/$($KeyVaultData.name)/objectId/$($KeyVaultData.svc_principal_id)"
$argList = @("import", "-var-file=`"vars\$Environment_Type.tfvars.json`"", "azurerm_key_vault_access_policy.k8s_sp_access[\`"$Environment_Name\`"]", $KvAccessId)    
Start-Process "terraform" -NoNewWindow -Wait -ArgumentList $argList -WorkingDirectory $WorkingDir

terraform state list

Pop-Location