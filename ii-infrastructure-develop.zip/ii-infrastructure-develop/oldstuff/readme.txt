This is stuff we worked on but did not complete or decided to remove
This stuff might come back in the future.  At this point in time we don't know
So it is preserved here just in case.

To future software archeologists.  These files are not used except as a historical record.
If no longer valuable, you should delete the whole folder. 