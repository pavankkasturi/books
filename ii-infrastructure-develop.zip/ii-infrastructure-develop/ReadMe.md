# II-Infrastructure

# Purpose
The purpose of this git repository is for provisioning the Azure PaaS Services that will be used by the Interactive Insights Services:

- Postgresql Database 
- Azure Redis Cache 
- Key Vault
- Log Analytics
- (future) Storage Account
- (future) Azure Service Bus Namespace 

# Environments, Environment Types and Deployments.
The Interactive Insights project has the concept of an environment type that encompasses several environments.  This allows us to share expensive resource like the PostreSQL database server and Azure Service Bus Namespace.  Each terraform deployment will be at the Environment Type level.  If an environment type includes multiple environments, the deployment has the potential to change all environments in that environment type.

For example the ***QAT*** Environment Type includes a single PostgreSQL database server named dgx-ii-psql-qa.  That database server is shared by the QA FUN, QA INT, QA BCK and QA PRD environments.  The terraform deployment is for QAT and all the environments that type includes.

# Methods for Provisioning

## Script Automation
The ***scripts*** folder contains a shell script named `launch-tf.sh`.  

This script requires a bash terminal and terraform on your workstation.
To install terraform on Ubuntu follow the instructions here: https://www.terraform.io/docs/cli/install/apt.html 

Before the script is run, you must configure a ***secrets.txt*** file.  
First, copy the ***example.secrets.txt*** to secrets.txt and then replace the XXX values with real secrets applicable to the environment.  

Some bash environments will require you to set the script permissions to executable.  Use `chmod +x launch-tf.sh` to make the script executable.

The first command line parameter passed to the script must be the environment type.  This will correspond to the name of a file in both the backend and vars folders.  Currently we have environment types named 'dev', 'qat', 'lt' and 'stg'.

The script can optionally accept 'apply' as the second command line parameter, which will automatically launch the ***terraform apply*** command after it completes the plan command.

### Steps to Execute
These commands use an example environment type name of *env*.  Replace *env* with the name of your environment type.

> cd scripts
>
> chmod +x launch-tf.sh
>
> cp example.secrets.txt secrets.txt

Edit secrets.txt and replace *XXX* with the secrets for the azure service principal for your environment.

Next verify that terraform is installed

> terraform --version
>
> ./launch-tf.sh env 

review the plan to ensure that terraform will do what you want it to do, then apply the changes.

> ./launch-tf.sh env apply

## Pipeline Automation
[This is broken at the moment but will be reconfigured soon]
Our GitLab pipelines are defined in the .gitlab.ci.yml file in this repository.  
The goal is to manually start the GitLab Pipelines so that we can select the II Environment to which we are deploying. 
We do not want the Pipelines to be triggered on pushes to the repository nor after a successful Merge Request in GitLab. This automation could be created at a later time if desired.

# Destroying Environments
Because our environments include populated databases, and because we rely on external groups to provision resource groups and private link IP addresses, destroying and rebuilding an environment is a costly operation.  For this reason destroying environments must be done manually.

## Destroying an Environment Type without terraform
Note: This process will affect a complete environment type with all of its environments.  For environment types like staging and load testing that have one environment with no shared resources, this is the easiest method.  If you need to remove a single environment that has shared resources follow the 'Destroying with terraform' process below.

1. In a text editor open the environment's backend/XXX.tfvars file
2. Log in to the azure portal
3. Using the information in the backend file, find and delete the tfstate file in the azure storage account.
4. Open the resource group for the environment
5. Select and delete the environment's resources 

## Destroying an Environment Type with terraform
This will destroy the shared database and anayltics workspace and the redis caches and keyvaults.

1. In the azure portal ensure that any resource locks have been removed
2. Edit the postredatabase.tf file.  Remove the lifecycle block with the `prevent_destroy = true` line
3. Execute the following commands

> ./scripts/launch-tf.sh env
>
> source ./scripts/secrets.txt
>
> terraform destroy

when prompted type in yes to confirm the environment destroy operation

Note: key vaults are soft deleted.  A key vault with the same name may not be created until the key vault is purged or the retention period has passed.

## Destroying a specific Environment's resources with terraform.
To remove one environment's redis cache and key vault (but not the shared database and analytics workspace), just remove that environments properties from 
the 'Redis' and 'Key_Vault'   

# Terraform
The important files in this repository for the Terraform configuration are:

- main.tf (This file contains the setup and the resource definitions for each resource which will be provisioned to Azure.)
- variables.tf (This file contains all of the Terraform variables declarations).
- var/*.tfvars.json (These files contain environment-specific values for the variables declared in variables.tf)
- backend/*.tfvars (These files contain azurerm backend configuration settings. They connect terraform to an azure storage account)

## Special Variables

### Authentication Environment Variables 
We use the Service Principal with Client Secret process to authenticate to Azure.  This process is documented by [Terraform](https://www.terraform.io/docs/language/settings/backends/azurerm.html)  The following environment variables are required for authentication :  ARM_TENANT_ID, ARM_SUBSCRIPTION_ID, ARM_CLIENT_ID and ARM_CLIENT_SECRET.

For the bash shell these environment variables are loaded from the secrets.txt file in the scripts folder.
For powershell these environment variables are loaded from the secrets.ps1 file in the scripts folder.

Use the following command to manually load the environment variables for bash

> source ./scripts/secrets.txt

Use the following command to manually load the environment variables for powershell

> . .\scripts\secrets.ps1



## Import Script
The ***scripts*** folder includes a PowerShell import script.  That script is intended to be run manually as a one time process to bring existing Azure resources into terraform's state file and get them 'under management' by terraform.

Importing resources into the state file is not something that should be done on a regular basis.

