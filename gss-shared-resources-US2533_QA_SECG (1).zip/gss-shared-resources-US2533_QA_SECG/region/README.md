# Introduction
AWS Terraform Region Module. Provides standard short codes for AWS regions that can be when naming resources. For example for AWS Region "us-east-1", the module returns "use1". The codes returns are based on static data. If additional AWS regions are added, the table inside the module must be updated.

The module also returns:
  ```current_region_name``` - the region that the environment is actively using (e.g. us-east-1)
  ```current_region_code``` - the region code of the active region. This code is derived from the region prefix used in availability zone ids. The value returned is derived from the first availability zone id in the active region. For example "use2-az1" would return "use2"
  ```current_region_zone_codes``` - returns the availability zone codes based on the availability zone names for the active region. For example if the availability zones in the active regions us-east-1a thru us-east-1f, a list containing ["a","b","c","d","e","f"] will be returned.

# Getting Started
To use this module in terraform, delare the module and pass in the region name you want to define. You can reference the module directly from git.

```terraform
  data "aws_region" "current" {}

  module "region" {
    source = "git::ssh://ssh.dev.azure.com/v3/dgx-infarch/aws-foundation/region.git"
    region_name = data.aws_region.current.name
  }
  locals {
    region_code = lower(module.region.code)
    zone_codes = module.region.current_region_zone_codes
  }
```

To reference a specific git tag  or branch use a `?ref=` suffix in the source variable. For example

  To reference a version that is tagged as v1.0:
    `source = "git::ssh://ssh.dev.azure.com/v3/dgx-infarch/aws-foundation/region.git?reg=v1.0"`

  To tag the latest version in the "develop" branch:
    `source = "git::ssh://ssh.dev.azure.com/v3/dgx-infarch/aws-foundation/region.git?ref=develop"`


# Build and Test
Checkout the develop branch. Create a sub-branch of develop to make your changes, then commit and test. Once you've completed merge you sub-branch back onto develop. To merge into production, contact the repo administrator.

# Contribute
Contact the repo administrator to get access to contribute


