final ENVIRONMENT = env.ENVIRONMENT ?: 'DEV'
final ACCOUNT_MAP = [
    DEV : '655609680260',
    SANDBOX: '114836847639'
]
final ACCOUNT_ID = ACCOUNT_MAP[ENVIRONMENT]
final ROLE_ARN = "arn:aws:iam::${ACCOUNT_ID}:role/iac-gss"
final ECR_REPO = "baseimages/jdk/corretto11"
final PARENT_VERSION = "11.0.12"
final DOCKER_FILE = "baseimages/Dockerfile.jdk-corretto11"

final GIT_REPO = "git@gitlab.com:questdiagnostics/consumergenomics/gss-shared-resources.git"
final GIT_BRANCH = env.BRANCH ?: "main"
final GIT_CREDENTIALS_ID = 'jenkins-gitlab-deploy-key'

node {
  stage('Checkout') {
    checkout scm
    git branch: GIT_BRANCH, url: GIT_REPO, credentialsId: GIT_CREDENTIALS_ID
  }

  def dkr = "${ACCOUNT_ID}.dkr.ecr.us-east-1.amazonaws.com/${ECR_REPO}"
  def imageTag = "${PARENT_VERSION}-${env.BUILD_NUMBER}"
  stage('Build & Push Docker Image') {
    withAWS(role: "${ROLE_ARN}") {
      sh "aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin ${dkr}"
      sh "docker build -f ${DOCKER_FILE} --build-arg VERSION=${PARENT_VERSION} --network=host -t ${dkr}:${imageTag} -t ${dkr}:latest ."
      sh "docker image push --all-tags ${dkr}"
    }
  }

  stage('Delete Docker Image') {
    sh "docker image rm ${dkr}:latest"
    sh "docker image rm ${dkr}:${imageTag}"
  }
}