library(
    identifier: "jenkins-shared-library@main",
    retriever: modernSCM(
        $class: 'GitSCMSource',
        remote: 'git@gitlab.com:questdiagnostics/consumergenomics/jenkins-shared-libraries.git',
        credentialsId: 'jenkins-gitlab-deploy-key'
    )).org.gss.jenkins

final ACCOUNT_IDS = [
    SANDBOX: "114836847639",
    DEV: "655609680260"
]

final TF_BACKENDS = [
    SANDBOX: "health-tf-state",
    DEV: "gss-dev-health-tf-state"
]

final IAC_ROLES = [
    SANDBOX: "iac-global",
    DEV: "iac-global"
]

final ACCOUNT_ID = ACCOUNT_IDS[env.AWS_ENV]
final ROLE_ARN = "arn:aws:iam::${ACCOUNT_ID}:role/${IAC_ROLES[env.AWS_ENV]}"

def config = [
    aws: [
        accountId: ACCOUNT_ID,
        groupId: "gss",
        region: "us-east-1",
        jenkinsIACRole: ROLE_ARN,
        stackId: "gss-databases",
        owner: "Pavan.Kasturi"
    ],
    git: [
        branch: env.BRANCH ?: "main",
        credentialsId: "jenkins-gitlab-deploy-key",
        repoUrl: "git@gitlab.com:questdiagnostics/consumergenomics/gss-shared-resources.git"
    ],
    terraform: [
        backend: TF_BACKENDS[env.AWS_ENV],
        workspace: env.TF_PATH
    ]
]

node {
    jenkinsIAC.call config
}
