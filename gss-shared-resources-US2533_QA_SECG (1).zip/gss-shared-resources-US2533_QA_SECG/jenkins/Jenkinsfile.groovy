library(
    identifier: "jenkins-shared-library@US2548/support-commandline-options",
    retriever: modernSCM(
        $class: 'GitSCMSource',
        remote: 'git@gitlab.com:questdiagnostics/consumergenomics/jenkins-shared-libraries.git',
        credentialsId: 'jenkins-gitlab-deploy-key'
    )).org.gss.jenkins

final ACCOUNT_IDS = [
    SANDBOX: "114836847639",
    DEV: "655609680260",
    QA: "069309935830"
]

final TF_BACKENDS = [
    SANDBOX: "health-tf-state",
    DEV: "gss-dev-health-tf-state",
    QA: "gss-qa-tf-states"
]

final IAC_ROLES = [
    SANDBOX: "iac-global",
    DEV: "iac-global",
    QA: "iac-global"
]

final ACCOUNT_ID = ACCOUNT_IDS[env.AWS_ENV]
final ROLE_ARN = "arn:aws:iam::${ACCOUNT_ID}:role/${IAC_ROLES[env.AWS_ENV]}"

def config = [
    aws: [
        accountId: ACCOUNT_ID,
        groupId: "gss",
        region: "us-east-1",
        jenkinsIACRole: ROLE_ARN,
        stackId: "gss",
        owner: "Desmond.Ndambi"
    ],
    git: [
        branch: env.BRANCH ?: "main",
        credentialsId: "jenkins-gitlab-deploy-key",
        repoUrl: "git@gitlab.com:questdiagnostics/consumergenomics/gss-shared-resources.git"
    ],
    terraform: [
        backend: TF_BACKENDS[env.AWS_ENV],
        workspace: env.TF_PATH,
        options: "-var=\'env=${env.AWS_ENV.toLowerCase()}\'"
    ]
]

node {
    jenkinsIAC.call config
}
