# network

AWS Foundation Network

This is the base foundation module for VPC, Subnet, Transit gateway-vpc attachment, routes etc.
