# base-network

The configuration inthis repo creates single VPC with 12 subnets (4 subnet types with 3 subnts (in 3 azs) in each type). VPC is attached to transit gateway.
Each subnet type is attached to different route-table, please refer to resources section to see what other components are being created.

## Requirements
This deployment requires Terraform version 0.12.24 or newer.
This modules calls a child module, those needs to be exist to work this code. 

## Dependencies
This deployment is taking all the required code from network module, those module needs to be exist before we use this deployment.

path of child module which needs to be exist before we use this module:

| Module Name | Path |
| ------ | ------ |
| network    | https://gitlab.com/questdiagnostics/qsuite/infrastructure/network |


## Resources create by deployment

Note: Resources creatd by deployment may vary based on refered network module.

| Resource | Quantity |Purpose |
| ------ | ------ | ------|
| VPC              | 1 | Vitual Private Cloud |
| Subnets          | 12 | Spliting VPC into multiple subnets. 4 types of subnets(App, Data, Util, Endpoint) with 3 subnets in each type |
| aws_route_table | 4 | one route table for each type of subnets |
| subnet-route table association | 12 | Association of each subnet to route table |
| aws_default_security_group | 1 | blocking 0.0.0.0/0 on default SG based on AWS best practices |
| aws_flow_log | 1 | Ip traffic to/from VPC,saving flowlogs ins3 bucket |
| aws_route| 4 | routes for each route table. Creating 4 routes since there is 4 route tables |
| aws_route53_record| 1 | test record to test once deployed |
| aws_route53_resolver_query_log_config | 1 | Logs of DNS Queries made by resources with in VPC. storing them in s3 bucket. |
| aws_route53_resolver_query_log_config_association | 1 | to associate with VPC  |
| aws_route53_zone | 1 | to manage Domain Name System |
| aws_security_group | 1 | one security group for interface endpoint |
| aws_vpc_endpoint | 7 | to access aws services without going over internet. endpoints for s3, efs, kms, ec2, ec2 messages, ssm, ssmmessages |
| aws_vpc_endpoint_route_table_association | 1 | route table for gateway endpoint |
|tgw.aws_ec2_transit_gateway_vpc_attachment |1 | attch vpc to transit gateway |

## Usage

1. clone the repo to your local machine.
2. provide access to your machine to access aws account 
3. Terraform needs to be installed. 

### init

```
terraform init
```
It will download the required plugings, providers and child modules, state file referred in code.
### Plan

```
terraform plan
```
It will show you what you going to create, change, destroy by this code.

**NOTE**: I highly recommend to go to each resource that you going to create, change, destroy and double check before apply. 

### Apply

```
terraform apply
```
It will show you what you going to create, change, destroy by this code just like plan and asks for approval, hit "yes" to proceed or "no" to discard.  

### Destroy

```
terraform destroy 
```

## Inputs


| Input                     | Type | Where to get info (as of now) | Description |
| ------------------------- | ------ | --------- | ------------- |
| project_name              | string | Project Manager | Name of Project |
| project_owner             | string | Project Manager | Owner of Project |
| region                    | string | Henrich | region where to create network |
| environment               | string | Henrich | which environment code intended to deploy |
| availability_zones        | list(string) | Henrich  | Which az's to use in region |
| tgw_id                    | string | Cloud admin(Then Chris now Vamsi i guess)  | tgw_id to attach VPC |
| shared_dns_vpc            | map(string) | Cloud admin(Then Chris now Vamsi i guess) | vpc id and region of the shared dns resolver |
| vpc                       | object | Henrich | CIDR for VPC |
| subnet_util               | object | Henrich | size of subnets |
| subnet_endpoint           | object | Henrich | size of subnets |
| subnet_application        | object | Henrich | size of subnets |
| subnet_data               | object | Henrich | size of subnets |
| standard_tags             | map | Henrich | common tags to each resource |
| create_bucket             | bool | Henrich | bucket to store flowlogs |
| bucket_arn                | string | Henrich | bucket arn to store flowlogs |
| create_route53_logs_bucket| bool | Henrich | bucket to store dns-resolver-query-logs |
| route53_logs_bucket_arn   | string | Henrich | arn of bucket to store dns-resolver-query-logs |

## Outputs
It will retun the o/p's once terraform code is executed 
EX: our code creates VPC and gives VPC id as output.

| output name | what is in there |
| ------ | ------ |
|current_region_name | Will get region name (ex:us-east-1,us-west-2) |
| current_region_code | Will get region code (ex:use-1 for us-east-1) |
| vpc | VPC-id |
| to_onprem | CIDR's of on-prem |
| subnet_data | Info about all data subnets |
| application | Info about all application subnets |
| subnet_util | Info about all util subnets |
| subnet_endpoint | Info about all endpoint subnets |
| ASK_A_CLOUD_ADMIN | will retun the command to enable dns hosted zone |
| dns_zone | Info about dns zone we created |

## Post deployment work 
 
 There will be some post deployment work needs to be done to complete the network setup 100%.

| Task | What to do |
| ------ | ------ |
| Need to assign route table to vpc-trasit gateway attchemnt to connect to resources in VPC | Contact Vamsi to do it |
| Need to enable the dns zone | will get o/p called "ASK_A_CLOUD_ADMIN" once deployment is done. Ask cloud admin to run that command in network account. |
