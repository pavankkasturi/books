# GSS-Shared-Resources

terraform scripts and jenkins file for shared resources / basic infrastructure for GSS portal