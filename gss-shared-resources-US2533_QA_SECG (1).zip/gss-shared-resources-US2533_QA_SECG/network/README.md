# network

This is the network module, 
The content of this repo now contains a network module rather than deployments.

The base-network deployment will call this module to manage the networking components.

In top level view this module is designed to create a single VPC with 12 subnets (4 subnet types with 3 subnts in each type). VPC is attached to transit gateway.
Each subnet type is attached to different route-table, please refer to resources section to see what other components are being created  


## Requirements
This module requires Terraform version 0.12.24 or newer.
This modules calls multiple child modules, those needs to be exist to work this code. 

## Dependencies
This module is taking vpc,subnet,region code from other modules, those modules needs to be exist before we use this module.

path of child modules which needs to be exist before we use this module:

| Module Name | Path |
| ------ | ------ |
| VPC              |https://gitlab.com/questdiagnostics/qsuite/foundation/network/-/tree/develop/vpc |
| Subnet           |https://gitlab.com/questdiagnostics/qsuite/foundation/network/-/tree/develop/subnet-common |
|TGW-VPC attach    |https://gitlab.com/questdiagnostics/qsuite/foundation/network/-/tree/develop/tgw-attach |
| Routes           |https://gitlab.com/questdiagnostics/qsuite/foundation/network/-/tree/develop/routes |
| Region           |https://gitlab.com/questdiagnostics/qsuite/foundation/region|


## Resources create by module

| Resource | Quantity |Purpose |
| ------ | ------ | ------|
| VPC              | 1 | Vitual Private Cloud |
| Subnets          | 12 | Spliting VPC into multiple subnets. 4 types of subnets(App, Data, Util, Endpoint) with 3 subnets in each type |
| aws_route_table | 4 | one route table for each type of subnets |
| subnet-route table association | 12 | Association of each subnet to route table |
| aws_default_security_group | 1 | blocking 0.0.0.0/0 on default SG based on AWS best practices |
| aws_flow_log | 1 | Ip traffic to/from VPC,saving flowlogs ins3 bucket |
| aws_route| 4 | routes for each route table. Creating 4 routes since there is 4 route tables |
| aws_route53_record| 1 | test record to test once deployed |
| aws_route53_resolver_query_log_config | 1 | Logs of DNS Queries made by resources with in VPC. storing them in s3 bucket. |
| aws_route53_resolver_query_log_config_association | 1 | to associate with VPC  |
| aws_route53_zone | 1 | to manage Domain Name System |
| aws_security_group | 1 | one security group for interface endpoint |
| aws_vpc_endpoint | 7 | to access aws services without going over internet. endpoints for s3, efs, kms, ec2, ec2 messages, ssm, ssmmessages |
| aws_vpc_endpoint_route_table_association | 1 | route table for gateway endpoint |
|tgw.aws_ec2_transit_gateway_vpc_attachment |1 | attch vpc to transit gateway |

## Usage
we have to use this module at deployment,To use this module at deployment refer like below,and pass the required perameters there.

```hcl
Below is just example of how i used this module in deployment section.
## main.tf file

 module "network" {
  source = "git::ssh://git@gitlab.com/questdiagnostics/qsuite/infrastructure/network.git?ref=main"
  project_name               = var.project_name
  project_owner              = var.project_owner
  vpc                        = var.vpc
  availability_zones         = var.availability_zones
  subnet_util                = var.subnet_util
  subnet_data                = var.subnet_data
  subnet_application         = var.subnet_application
  tgw_id                     = var.tgw_id
  subnet_endpoint            = var.subnet_endpoint
  tgw_route_table_id         = var.tgw_route_table_id
  shared_dns_vpc             = var.shared_dns_vpc
  region                     = var.region
  environment                = var.environment
  standard_tags              = var.standard_tags
  create_bucket              = var.create_bucket
  bucket_arn                 = var.bucket_arn
  create_route53_logs_bucket = var.create_route53_logs_bucket
  route53_logs_bucket_arn    = var.route53_logs_bucket_arn
}

## var.tf file
variable bucket_arn {
    type = string
}

## terraform.tfvars file
bucket_arn    = "arn:aws:s3:::dgx-protected-security-logs-us-east-1-439201868322"

```

Note: This is a re-usable module, can be used for multiple deployments. we are using this module to create network in env's like dev,tst,val,prd...


## Usage
We do not execute any commands here since it is just a module not a deployment. 

## Inputs
Do not need to pass any inputs here, pass all the values in deployemnet section.

## Outputs
It will retun the o/p's once terraform code is executed 
EX: our code creates VPC and gives VPC id as output.

| output name | what is in there |
| ------ | ------ |
|current_region_name | Will get region name (ex:us-east-1,us-west-2) |
| current_region_code | Will get region code (ex:use-1 for us-east-1) |
| vpc | VPC-id |
| to_onprem | CIDR's of on-prem |
| subnet_data | Info about all data subnets |
| application | Info about all application subnets |
| subnet_util | Info about all util subnets |
| subnet_endpoint | Info about all endpoint subnets |
| ASK_A_CLOUD_ADMIN | will retun the command to enable dns hosted zone |
| dns_zone | Info about dns zone we created |
